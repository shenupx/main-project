<?php
$con=mysqli_connect("localhost","root","") or die ('unable to connect database');
mysqli_select_db("project",$con) or die('could not select database');

?>