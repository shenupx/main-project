<?php
$con=mysqli_connect("localhost","root","","corephp") or die ("database error");



?>