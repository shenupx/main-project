<?php
include("connect.php");
$id=$_GET['id'];
mysqli_query($con,"delete from usr_details where id= '$id'") or die("error");
header("Refresh:0; url=view.php");
?>