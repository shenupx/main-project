<?php
include("connect.php");
$id=$_GET['id'];
if(isset($_POST["submitt"]))
{
$name=$_POST["updateuname"];
$addr=$_POST["updateaddress"];
$phn=$_POST["updatephone"];
mysqli_query($con,"update usr_details set name='$name', address='$addr', phone='$phn' where id=$id");
header("Refresh:0; url=view.php");
}
?>
<html>
<head>
</head>
<body>
<form action="#" method="post">
<table >
<br />
<?php 
$s=mysqli_query($con,"select * from usr_details where id =$id");
while($r=mysqli_fetch_array($s)){
  ?>
<tr> <th> Name </th>
<td> <input type="text" name="updateuname"  value="<?php echo $r['name']; ?> " /></td></tr>
<tr> <th> Address </th>
<td> <input type="text" name="updateaddress" value="<?php echo $r['address']; ?>"  /> </td></tr>
<tr> <th> Phone </th>
<td> <input type="number" name="updatephone" value="<?php echo $r['phone']; ?>"  /> </td></tr>
<tr> <td>
<?php } ?>
<input type="submit" name="submitt" value="UPDATE"  /></td></tr>

</table>
</form>

</body>
</html>