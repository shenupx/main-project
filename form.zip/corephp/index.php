<?php
include("connect.php");
if(isset($_POST["submit1"]))
{
$name=$_POST["uname"];
$addr=$_POST["address"];
$phn=$_POST["phone"];
mysqli_query($con,"INSERT INTO `usr_details`(`name`, `address`, `phone`) VALUES ('$name','$addr','$phn')");
echo "successfully inserted";    
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>index</title>
</head>

<body>
<form action="#" method="post">
<table >
<br />

<tr> <th> Name </th>
<td> <input type="text" name="uname"  /></td></tr>
<tr> <th> Address </th>
<td> <input type="text" name="address"  /> </td></tr>
<tr> <th> Phone </th>
<td> <input type="number" name="phone"  /> </td></tr>
<tr> <td>
<input type="submit" name="submit1" value="SUBMIT"  /></td></tr>

</table>
</form>
<a href="view.php" > View User Details</a>
</body>
</html>
