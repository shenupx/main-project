
<html>
<?php
include("connect.php");

$s=mysqli_query($con,"select * from usr_details");


  ?>
  <body>
<table border="1">
<tr>
<th> name </th>
<th> address </th>
<th> Phone</th>
<th> edit</th>
<th> delete</th>
</tr>
<?php 
while($r=mysqli_fetch_array($s)){
?>
<tr>
 <td> <?php echo $r['name']; ?> </td>
<td> <?php echo $r['address']; ?> </td>
<td> <?php echo $r['phone']; ?> </td>
<td> <a href="edit.php?id=<?php echo $r['id']; ?>"> EDIT </a> </td>
<td> <a href="delete.php?id=<?php echo $r['id']; ?> ">DELETE</a></td>

 </tr>
 <?php 
 }
 ?>
</table>
</body>
</html>
