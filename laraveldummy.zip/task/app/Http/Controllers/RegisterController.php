<?php

namespace App\Http\Controllers;

use App\Register;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $register=Register::all(); //all is a facade it is already defined.
      $registerdetails=Register::all();
      return view('register.index',compact('registerdetails'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('register.register');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $register=new Register([
        'name'=>$request->get('name'),
        'email'=>$request->get('email'),
        'phone'=>$request->get('phone'),
        'username'=>$request->get('username'),
        'password'=>$request->get('password')
      ]);
      $register->save();
     return redirect('/register/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $register=Register::find($id);

      return view('register.edit',compact('register'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $register=Register::find($id);
      $register->name=$request->get('name');
      $register->email=$request->get('email');
      $register->phone=$request->get('phone');
      $register->username=$request->get('username');
      $register->password=$request->get('password');
      $register->save();
      return redirect('/register');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      $register=Register::find($id);
      $register->delete();
      return redirect('/register');
    }
}
