<html>
<form method="post" action="{{route('book.store')}}">
  @csrf
  title:  <input type="text" name="title"> <br/>
body : <input type="text" name ="body">
<br />
<button type="submit" >ADD </buttton>
</form>
