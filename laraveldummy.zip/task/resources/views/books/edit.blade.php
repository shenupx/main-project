<form method="post" action="{{route('book.update',$books->id)}}">
  @method('PATCH')
  @csrf
  <label for="name">Title:</label>
  <input type="text" name="title" value="{{$books->title}}" /><br/>
  <label for="price">Body:</label>
  <input type="text" name="body" value="{{$books->body}}" /><br/>
  <button type="submit"> UPDATE </button>
</form>
<!--  action= book controller ile update enna method ne call cheyyunnu
athilek id pass cheyyunnu

-->
