<table border="1">
  <thead>
    <tr>
      <td>Id</td>
      <td> Title</td>
      <td>Body</td>

  </thead>
  <tbody>
    @foreach($booksdetails as $book)
    <tr>
      <td>{{$book->id}}</td>
        <td>{{$book->title}}</td>
          <td>{{$book->body}}</td>
          <td><a href="{{route('book.edit',$book->id)}}">Edit</a></td>
            <td><form action="{{route('book.destroy',$book->id)}}" method="post">
              @csrf
              @method('DELETE')
              <button type="submit"> delete </button>
            </form>
          </td>
      </tr>
      @endforeach
    </tbody>
</table>
<!--$book use cheyyanath oro raw neyum temperary aayi use cheyyan
Oro iteration nte values um $bookil kitum.
