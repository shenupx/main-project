<form method="post" action="{{route('register.update',$register->id)}}">
  @method('PATCH')
  @csrf
  <label for="name">name:</label>
  <input type="text" name="name" value="{{$register->name}}" /><br/>
  <label for="price">email:</label>
  <input type="text" name="email" value="{{$register->email}}" /><br/>
  <label for="name">phone:</label>
  <input type="text" name="phone" value="{{$register->phone}}" /><br/>
  <label for="price">username:</label>
  <input type="text" name="username" value="{{$register->username}}" /><br/>
  <label for="price">password:</label>
  <input type="text" name="password" value="{{$register->password}}" /><br/>
  <button type="submit"> UPDATE </button>
</form>
