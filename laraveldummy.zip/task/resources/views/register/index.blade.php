<table border="1">
  <thead>
    <tr>
      <td>Id</td>
      <td> name</td>
      <td>email</td>
      <td>phone</td>
      <td> username</td>
      <td>password</td>

  </thead>
  <tbody>
    @foreach($registerdetails as $register)
    <tr>
      <td>{{$register->id}}</td>
        <td>{{$register->name}}</td>
          <td>{{$register->email}}</td>
          <td>{{$register->phone}}</td>
            <td>{{$register->username}}</td>
            <td>{{$register->password}}</td>
          <td><a href="{{route('register.edit',$register->id)}}">Edit</a></td>
            <td><form action="{{route('register.destroy',$register->id)}}" method="post">
              @csrf
              @method('DELETE')
              <button type="submit"> delete </button>
            </form>
          </td>
      </tr>
      @endforeach
    </tbody>
</table>
<!--$book use cheyyanath oro raw neyum temperary aayi use cheyyan
Oro iteration nte values um $bookil kitum.
