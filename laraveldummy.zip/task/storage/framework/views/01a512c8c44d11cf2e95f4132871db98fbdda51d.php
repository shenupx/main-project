<html>
<form method="post" action="<?php echo e(route('book.store')); ?>">
  <?php echo csrf_field(); ?>
  title:  <input type="text" name="title"> <br/>
body : <input type="text" name ="body">
<br />
<button type="submit" >ADD </buttton>
</form>
