<table border="1">
  <thead>
    <tr>
      <td>Id</td>
      <td> name</td>
      <td>email</td>
      <td>phone</td>
      <td> username</td>
      <td>password</td>

  </thead>
  <tbody>
    <?php $__currentLoopData = $registerdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($register->id); ?></td>
        <td><?php echo e($register->name); ?></td>
          <td><?php echo e($register->email); ?></td>
          <td><?php echo e($register->phone); ?></td>
            <td><?php echo e($register->username); ?></td>
            <td><?php echo e($register->password); ?></td>
          <td><a href="<?php echo e(route('register.edit',$register->id)); ?>">Edit</a></td>
            <td><form action="<?php echo e(route('register.destroy',$register->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit"> delete </button>
            </form>
          </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!--$book use cheyyanath oro raw neyum temperary aayi use cheyyan
Oro iteration nte values um $bookil kitum.
