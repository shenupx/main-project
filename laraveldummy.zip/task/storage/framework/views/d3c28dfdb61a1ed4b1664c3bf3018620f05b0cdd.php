<form method="post" action="<?php echo e(route('register.update',$register->id)); ?>">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <label for="name">name:</label>
  <input type="text" name="name" value="<?php echo e($register->name); ?>" /><br/>
  <label for="price">email:</label>
  <input type="text" name="email" value="<?php echo e($register->email); ?>" /><br/>
  <label for="name">phone:</label>
  <input type="text" name="phone" value="<?php echo e($register->phone); ?>" /><br/>
  <label for="price">username:</label>
  <input type="text" name="username" value="<?php echo e($register->username); ?>" /><br/>
  <label for="price">password:</label>
  <input type="text" name="password" value="<?php echo e($register->password); ?>" /><br/>
  <button type="submit"> UPDATE </button>
</form>
