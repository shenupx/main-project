<html>
<form method="post" action="<?php echo e(route('register.store')); ?>">
  <?php echo csrf_field(); ?>
  name:  <input type="text" name="name"> <br/>
email : <input type="text" name ="email"><br/>
phone : <input type="text" name ="phone"><br/>
username : <input type="text" name ="username"><br/>
password : <input type="text" name ="password"><br/>
<br />
<button type="submit" >REGISTER </buttton>
</form>
