import { Component, OnInit } from '@angular/core';
import{Student} from '../student';
import{DemoService} from '../demo.service';
import{Form, NgForm} from '@angular/forms';
  import { from } from 'rxjs';
import { store } from '@angular/core/src/render3';

@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {
  student=new Student();
  error:any;
  isRegistred=false;
  constructor(private applydemo:DemoService) { }
  
  ngOnInit() { }
  registration(f:NgForm){
    this.applydemo.store(this.student).subscribe(data=>{
      this.isRegistred=true;
      console.log("Registered Successfully");
      //reset the form
      f.reset();   
    },
    (err)=>{this.error=err;
    this.isRegistred=false;
  }); 
  }
}
