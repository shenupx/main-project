export class Student{
    name : string;
    username:  string;
    password: string;
    status: string;
    id?:number;
    constructor(){

        
    }
}
