﻿using System.Web.UI;

namespace webapp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}